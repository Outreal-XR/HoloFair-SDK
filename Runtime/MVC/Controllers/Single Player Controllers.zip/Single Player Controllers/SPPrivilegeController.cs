namespace outrealxr.holomod
{
    public class SPPrivilegeController : Controller
    {
        public override void Handle()
        {
            
        }
    }   
}