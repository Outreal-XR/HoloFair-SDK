namespace outrealxr.holomod
{
    public class SPPlayableDirectorController : Controller
    {
        public override void Handle()
        {
            
        }
    }
}